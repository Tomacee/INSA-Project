package com.example.viewmodel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.database.AppDatabase
import com.example.database.ScanEntity
import com.example.repository.ScanRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class VeritasTab {
    SCANNER,
    ANALYSIS,
    HISTORY,
    PROFILE
}

class VeritasViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application)
    private val repository = ScanRepository(database.scanDao())

    // Reactive list of previous forensic scans from Room storage
    val scanHistoryList: StateFlow<List<ScanEntity>> = repository.allScans
        .catch { e ->
            e.printStackTrace()
            emit(emptyList())
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Current State Management
    var activeTab by mutableStateOf(VeritasTab.SCANNER)
    var activeScanReport by mutableStateOf<ScanEntity?>(null)
    var isScanning by mutableStateOf(false)
    var scannerInputText by mutableStateOf("")
    var isUrlMode by mutableStateOf(true) // default: scan URL / trust indicator
    var errorMessage by mutableStateOf<String?>(null)

    // Settings Profile States (matches mockup screen elements)
    var isDarkModeEnabled by mutableStateOf(false)
    var isHighRiskAlertsEnabled by mutableStateOf(true)
    var forensicScansDoneCount by mutableStateOf(84) // starting out at mockup "84 / 100" scan capacity

    fun updateInputText(text: String) {
        scannerInputText = text
    }

    fun setScannerMode(asUrl: Boolean) {
        isUrlMode = asUrl
    }

    fun selectScanReport(entity: ScanEntity) {
        activeScanReport = entity
        activeTab = VeritasTab.ANALYSIS // automatically navigate to detailed report screen
    }

    /**
     * Executes the forensic content verification scanner.
     */
    fun startForensicAnalysis() {
        val input = scannerInputText.trim()
        if (input.isEmpty()) {
            errorMessage = "Please enter an article URL, source name, or text to continue the scan."
            return
        }
        if (isScanning) return // Prevent duplicate concurrent scan launches from fast double-clicks

        isScanning = true
        errorMessage = null
        viewModelScope.launch {
            try {
                // Trigger scanner in repository
                val scanResultEntity = repository.performScan(input, isUrlMode)
                activeScanReport = scanResultEntity
                forensicScansDoneCount = (forensicScansDoneCount + 1).coerceAtMost(100)
                
                // Clear input after successful scan
                scannerInputText = ""
                
                // Switch focus to the detailed Analysis/Verification tab
                activeTab = VeritasTab.ANALYSIS
            } catch (e: Exception) {
                errorMessage = "Forensic check failed: ${e.message}. Please verify connection."
            } finally {
                isScanning = false
            }
        }
    }

    fun deleteHistoricalScan(scanId: Int) {
        viewModelScope.launch {
            try {
                repository.deleteScan(scanId)
                if (activeScanReport?.id == scanId) {
                    activeScanReport = null
                }
            } catch (e: Exception) {
                errorMessage = "Failed to delete scan: ${e.message}"
            }
        }
    }

    fun clearScansHistory() {
        viewModelScope.launch {
            try {
                repository.clearHistory()
                activeScanReport = null
            } catch (e: Exception) {
                errorMessage = "Failed to clear history log: ${e.message}"
            }
        }
    }
}

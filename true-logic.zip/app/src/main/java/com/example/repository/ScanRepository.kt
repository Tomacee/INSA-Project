package com.example.repository

import com.example.database.ScanDao
import com.example.database.ScanEntity
import com.example.model.GeminiScanResult
import com.example.network.RetrofitClient
import kotlinx.coroutines.flow.Flow

class ScanRepository(private val scanDao: ScanDao) {

    val allScans: Flow<List<ScanEntity>> = scanDao.getAllScans()

    /**
     * Executes the fact-check forensic scan via Gemini API or fallback,
     * stores it in the native Room database, and returns the entity.
     */
    suspend fun performScan(inputText: String, isUrl: Boolean): ScanEntity {
        // Run AI scanning analysis
        val result: GeminiScanResult = RetrofitClient.scanContent(inputText, isUrl)

        // Convert Claims list to stringified JSON for local persistence database
        val jsonClaimText = RetrofitClient.resultAdapter.toJson(result)

        val entity = ScanEntity(
            title = result.title,
            contentRaw = inputText,
            sourceUrl = if (isUrl) inputText else "",
            trustLevel = result.trustLevel,
            confidenceScore = result.confidenceScore,
            perspective = result.perspective,
            claimAnalysisJson = jsonClaimText
        )

        val generatedId = scanDao.insertScan(entity)
        return entity.copy(id = generatedId.toInt())
    }

    suspend fun deleteScan(scanId: Int) {
        scanDao.deleteScanById(scanId)
    }

    suspend fun clearHistory() {
        scanDao.clearAllScans()
    }
}

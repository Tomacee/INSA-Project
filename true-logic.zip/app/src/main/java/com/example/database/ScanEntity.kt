package com.example.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "scans")
data class ScanEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val contentRaw: String,
    val sourceUrl: String,
    val trustLevel: String, // VERIFIED, CLICKBAIT, MISINFORMATION
    val confidenceScore: Int, // 0 - 100
    val perspective: String,
    val claimAnalysisJson: String, // Stringified JSON of list of claims
    val timestamp: Long = System.currentTimeMillis()
)

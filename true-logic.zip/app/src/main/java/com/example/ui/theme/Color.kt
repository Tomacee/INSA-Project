package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Veritas Logic Brand Color Palette tokens
val VeritasPrimary = Color(0xFF091426)           // Authoritative Deep Slate Black
val VeritasSecondary = Color(0xFF4b41e1)         // Modern Indigo Accent
val VeritasSecondaryContainer = Color(0xFF645efb)// Rich Indigo Hover/Focus
val VeritasBackground = Color(0xFFF8F9FF)        // Calm Cooling Neutral Canvas
val VeritasSurface = Color(0xFFF8F9FF)           // Level 0 Base Layer
val VeritasSurfaceContainerLowest = Color(0xFFFFFFFF) // Level 1 Tonal elevation card
val VeritasSurfaceContainerLow = Color(0xFFEFF4FF)    // Tier 1 subtle negative space
val VeritasSurfaceContainer = Color(0xFFE5EEFF)       // Tier 2 spacing layer
val VeritasSurfaceContainerHigh = Color(0xFFDCE9FF)   // Tier 3 separator stroke background
val VeritasSurfaceContainerHighest = Color(0xFFD3E4FE)// Top Nav drawer divider tint
val VeritasOnSurface = Color(0xFF0B1C30)              // High-trust Slate Text
val VeritasOnSurfaceVariant = Color(0xFF45474C)      // Medium-contrast body copy text
val VeritasInverseSurface = Color(0xFF213145)        // Contrast overlay dark theme sheet
val VeritasInverseOnSurface = Color(0xFFEAF1FF)      // Contrast text sheet

// Case status colors
val VerifiedGreen = Color(0xFF16A34A)            // Confidence truth color
val ClickbaitAmber = Color(0xFFD97706)           // Sensationalism alert
val MisinfoRed = Color(0xFFDC2626)               // Falsehood indicator banner
val NeutralBlue = Color(0xFF2563EB)              // Balanced status badge

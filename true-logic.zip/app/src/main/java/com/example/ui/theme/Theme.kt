package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val LightColorScheme = lightColorScheme(
    primary = VeritasPrimary,
    onPrimary = Color.White,
    primaryContainer = VeritasPrimary,
    onPrimaryContainer = Color(0xFF8590A6),
    secondary = VeritasSecondary,
    onSecondary = Color.White,
    secondaryContainer = VeritasSecondaryContainer,
    onSecondaryContainer = Color.White,
    background = VeritasBackground,
    onBackground = VeritasOnSurface,
    surface = VeritasSurface,
    onSurface = VeritasOnSurface,
    surfaceVariant = VeritasSurfaceContainerHighest,
    onSurfaceVariant = VeritasOnSurfaceVariant,
    error = MisinfoRed,
    onError = Color.White,
    errorContainer = Color(0xFFFED7D7),
    onErrorContainer = MisinfoRed,
    outline = Color(0xFF75777D),
    outlineVariant = Color(0xFFC5C6CD)
)

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFFD8E3FB),
    onPrimary = Color(0xFF091426),
    primaryContainer = Color(0xFF1E293B),
    onPrimaryContainer = Color(0xFF8590A6),
    secondary = Color(0xFFC3C0FF),
    onSecondary = Color(0xFF0F0069),
    secondaryContainer = Color(0xFF4B41E1),
    onSecondaryContainer = Color.White,
    background = Color(0xFF0F172A), // Dark slate slate-900
    onBackground = Color(0xFFF1F5F9),
    surface = Color(0xFF0F172A),
    onSurface = Color(0xFFF1F5F9),
    surfaceVariant = Color(0xFF1E293B),
    onSurfaceVariant = Color(0xFF94A3B8),
    error = Color(0xFFEF4444),
    onError = Color.Black,
    errorContainer = Color(0xFF7F1D1D)
)

@Composable
fun VeritasTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Disable Android dynamic coloring to enforce brand colors precisely
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

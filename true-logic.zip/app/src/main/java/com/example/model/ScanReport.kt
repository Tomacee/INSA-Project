package com.example.model

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class Claim(
    val statement: String,
    val status: String, // VERIFIED, CONTRADICTED, UNVERIFIED
    val explanation: String
)

@JsonClass(generateAdapter = true)
data class GeminiScanResult(
    val title: String,
    val trustLevel: String, // VERIFIED, CLICKBAIT, MISINFORMATION
    val confidenceScore: Int, // 0 - 100
    val perspective: String,
    val claims: List<Claim>
)

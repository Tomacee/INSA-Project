package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.database.ScanEntity
import com.example.model.Claim
import com.example.model.GeminiScanResult
import com.example.network.RetrofitClient
import com.example.ui.theme.*
import com.example.viewmodel.VeritasTab
import com.example.viewmodel.VeritasViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val viewModel: VeritasViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            // Dynamic theme switcher linked directly to ViewModel dark state preference
            VeritasTheme(darkTheme = viewModel.isDarkModeEnabled) {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = { VeritasTopBar(viewModel) },
                    bottomBar = { VeritasNavigationBar(viewModel) }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        AnimatedContent(
                            targetState = viewModel.activeTab,
                            transitionSpec = {
                                fadeIn() togetherWith fadeOut()
                            },
                            label = "screen_navigation"
                        ) { tab ->
                            when (tab) {
                                VeritasTab.SCANNER -> ScannerScreen(viewModel)
                                VeritasTab.ANALYSIS -> AnalysisScreen(viewModel)
                                VeritasTab.HISTORY -> HistoryScreen(viewModel)
                                VeritasTab.PROFILE -> ProfileScreen(viewModel)
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- Top App Bar ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VeritasTopBar(viewModel: VeritasViewModel) {
    TopAppBar(
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Truth icon SVG representation drawing (Gavel or Check badge)
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .background(
                            color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.1f),
                            shape = RoundedCornerShape(8.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "⚖",
                        style = androidx.compose.ui.text.TextStyle(fontSize = 18.sp),
                        textAlign = TextAlign.Center
                    )
                }
                Text(
                    text = "True Logic",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                )
            }
        },
        actions = {
            val focusManager = LocalFocusManager.current
            // Quick navigation to user profile when clicking avatar
            Box(
                modifier = Modifier
                    .padding(end = 16.dp)
                    .size(36.dp)
                    .border(
                        width = 1.5.dp,
                        color = MaterialTheme.colorScheme.secondary,
                        shape = CircleShape
                    )
                    .clip(CircleShape)
                    .clickable {
                        focusManager.clearFocus()
                        viewModel.activeTab = VeritasTab.PROFILE
                    }
            ) {
                // High-fidelity fallback avatar showing Alex Reed initials
                Text(
                    text = "AR",
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f))
                        .wrapContentSize(Alignment.Center),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.background
        )
    )
}

// --- Bottom Navigation Bar ---
@Composable
fun VeritasNavigationBar(viewModel: VeritasViewModel) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.background,
        tonalElevation = 8.dp
    ) {
        val focusManager = LocalFocusManager.current
        val tabList = listOf(
            VeritasNavigationItem(
                tab = VeritasTab.SCANNER,
                label = "Scanner",
                activeIcon = "🔍",
                inactiveIcon = "🔎"
            ),
            VeritasNavigationItem(
                tab = VeritasTab.ANALYSIS,
                label = "Analysis",
                activeIcon = "📈",
                inactiveIcon = "📉"
            ),
            VeritasNavigationItem(
                tab = VeritasTab.HISTORY,
                label = "Source Log",
                activeIcon = "🛡️",
                inactiveIcon = "🛡️"
            ),
            VeritasNavigationItem(
                tab = VeritasTab.PROFILE,
                label = "Profile",
                activeIcon = "👤",
                inactiveIcon = "👤"
            )
        )

        tabList.forEach { item ->
            val isSelected = viewModel.activeTab == item.tab
            NavigationBarItem(
                selected = isSelected,
                onClick = {
                    focusManager.clearFocus()
                    viewModel.activeTab = item.tab
                },
                icon = {
                    Text(
                        text = if (isSelected) item.activeIcon else item.inactiveIcon,
                        fontSize = 20.sp
                    )
                },
                label = {
                    Text(
                        text = item.label,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = MaterialTheme.colorScheme.secondary,
                    selectedTextColor = MaterialTheme.colorScheme.secondary,
                    indicatorColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f),
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                )
            )
        }
    }
}

data class VeritasNavigationItem(
    val tab: VeritasTab,
    val label: String,
    val activeIcon: String,
    val inactiveIcon: String
)

// --- SCREEN 1: SCANNER / INPUT SCREEN ---
@Composable
fun ScannerScreen(viewModel: VeritasViewModel) {
    val focusManager = LocalFocusManager.current
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            Column(modifier = Modifier.padding(vertical = 12.dp)) {
                Text(
                    text = "Verify Information Sources",
                    style = MaterialTheme.typography.titleLarge.copy(fontSize = 22.sp),
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Verify articles, analyze bias, and extract claims using open forensic models.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Toggles between link/search scanning mode vs raw block text
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    val urlColor = if (viewModel.isUrlMode) MaterialTheme.colorScheme.secondary else Color.Transparent
                    val urlTextColor = if (viewModel.isUrlMode) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(urlColor)
                            .clickable { viewModel.setScannerMode(true) }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Scan URL / Platform Link",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = urlTextColor
                        )
                    }

                    val textColor = if (!viewModel.isUrlMode) MaterialTheme.colorScheme.secondary else Color.Transparent
                    val textTextColor = if (!viewModel.isUrlMode) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(textColor)
                            .clickable { viewModel.setScannerMode(false) }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Paste Article Block",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = textTextColor
                        )
                    }
                }
            }
        }

        // Input search bar structure
        item {
            OutlinedTextField(
                value = viewModel.scannerInputText,
                onValueChange = { viewModel.updateInputText(it) },
                placeholder = {
                    Text(
                        text = if (viewModel.isUrlMode)
                            "e.g., https://nasa.gov/mars-water-discovery"
                        else
                            "Paste article excerpt or specific claim and query to audit details...",
                        style = MaterialTheme.typography.bodyMedium
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 120.dp, max = 220.dp),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.secondary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                    focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
                    disabledContainerColor = MaterialTheme.colorScheme.surfaceContainerLowest
                )
            )
        }

        // Scan launch buttons
        item {
            Button(
                onClick = {
                    focusManager.clearFocus()
                    viewModel.startForensicAnalysis()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.secondary
                ),
                enabled = !viewModel.isScanning
            ) {
                if (viewModel.isScanning) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(24.dp),
                        color = Color.White,
                        strokeWidth = 2.5.dp
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "Running Forensic Scans...",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Bold
                    )
                } else {
                    Text(
                        text = "Run True Logic Diagnostic",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Error message warning
        if (viewModel.errorMessage != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "❌", fontSize = 20.sp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = viewModel.errorMessage ?: "",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }
        }

        // Forensic Scan Templates Title
        item {
            Text(
                text = "Preset Audit Templates",
                style = MaterialTheme.typography.titleLarge.copy(fontSize = 18.sp),
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 16.dp)
            )
        }

        // preset clinical/news samples
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                PresetSuggestionCard(
                    title = "🛰️ NASA Rover Liquid Water Martian Profile",
                    description = "Scientific verify pattern scanning Rover captured hydration profiles.",
                    onClick = {
                        focusManager.clearFocus()
                        viewModel.isUrlMode = true
                        viewModel.updateInputText("https://spaceworld.com/nasa-perseverance-confirms-water-mars")
                        viewModel.startForensicAnalysis()
                    }
                )
                PresetSuggestionCard(
                    title = "⚡ Water Engine Electrolysis Fuel Breakthrough",
                    description = "Exaggerated patent review looking at infinite output mechanical loops.",
                    onClick = {
                        focusManager.clearFocus()
                        viewModel.isUrlMode = false
                        viewModel.updateInputText("Electrolysis claims to split pure water to fuel standard engines endlessly without fuel depletion.")
                        viewModel.startForensicAnalysis()
                    }
                )
                PresetSuggestionCard(
                    title = "🍎 Apple AI Silicon On-Device Neural Co-processor",
                    description = "Press validation auditing matrix chip acceleration specifications.",
                    onClick = {
                        focusManager.clearFocus()
                        viewModel.isUrlMode = true
                        viewModel.updateInputText("https://techinsider.com/apple-silicon-ai-hardware/")
                        viewModel.startForensicAnalysis()
                    }
                )
            }
        }
    }
}

@Composable
fun PresetSuggestionCard(title: String, description: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

// --- SCREEN 2: SOURCE VERIFICATION SCREEN (REPORT PAGE) ---
@Composable
fun AnalysisScreen(viewModel: VeritasViewModel) {
    val report = viewModel.activeScanReport

    if (report == null) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = "🛡️", fontSize = 64.sp)
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Report View Console is Empty",
                style = MaterialTheme.typography.titleLarge,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Type an article URL or content block under the Scanner screen and run 'True Logic Diagnostic' to create active truth sheets.",
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        }
        return
    }

    // Try parsing claims from jsonClaimText using Moshi, or configure a safe fallback
    val parsedResult: GeminiScanResult? = try {
        RetrofitClient.resultAdapter.fromJson(report.claimAnalysisJson)
    } catch (e: Exception) {
        null
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            Column(modifier = Modifier.padding(vertical = 12.dp)) {
                Text(
                    text = "Forensic Verification Report",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Source Content: ${if (report.sourceUrl.isNotEmpty()) report.sourceUrl else "Pasted text excerpt block"}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Headline title of source report
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = report.title,
                        style = MaterialTheme.typography.titleLarge.copy(fontSize = 20.sp),
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // Verified, Clickbait, or Misinformation dynamic layout chip
                    TruthStatusChip(trustLevel = report.trustLevel)
                }
            }
        }

        // Confidence progress meter card
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Confidence gauge bento block
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Confidence Index",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "${report.confidenceScore}%",
                            style = MaterialTheme.typography.headlineLarge.copy(fontFamily = FontFamily.Monospace),
                            color = MaterialTheme.colorScheme.secondary,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        // Progress bar indication
                        val progressColor = when (report.trustLevel) {
                            "VERIFIED" -> VerifiedGreen
                            "CLICKBAIT" -> ClickbaitAmber
                            else -> MisinfoRed
                        }
                        LinearProgressIndicator(
                            progress = { report.confidenceScore / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = progressColor,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    }
                }

                // Perspective bento block
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Core Perspective",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = report.perspective,
                            style = MaterialTheme.typography.titleLarge.copy(fontFamily = FontFamily.Monospace),
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        // Decorative horizontal line
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                        )
                    }
                }
            }
        }

        // Claims list title
        item {
            Text(
                text = "Claims Forensic Breakdown",
                style = MaterialTheme.typography.titleLarge.copy(fontSize = 18.sp),
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 12.dp)
            )
        }

        // Render each logical claim
        if (parsedResult?.claims != null && parsedResult.claims.isNotEmpty()) {
            items(parsedResult.claims) { claim ->
                ClaimDetailCard(claim)
            }
        } else {
            item {
                // Fallback claim if everything is empty
                ClaimDetailCard(
                    Claim(
                        statement = "The subject claims absolute structural authenticity.",
                        status = "UNVERIFIED",
                        explanation = "Forensic systems could not map specific claim structures. External citation backup needed."
                    )
                )
            }
        }
    }
}

@Composable
fun TruthStatusChip(trustLevel: String) {
    val (chipBg, chipTextColor, chipLabel) = when (trustLevel) {
        "VERIFIED" -> Triple(
            VerifiedGreen.copy(alpha = 0.1f),
            VerifiedGreen,
            "VERIFIED — Standard Truth Alignment"
        )
        "CLICKBAIT" -> Triple(
            ClickbaitAmber.copy(alpha = 0.1f),
            ClickbaitAmber,
            "SENSATIONALIST — Exaggerated Headline Bounds"
        )
        else -> Triple(
            MisinfoRed.copy(alpha = 0.1f),
            MisinfoRed,
            "MISINFORMATION — Falsehood Signatures Blocked"
        )
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(chipBg)
            .padding(horizontal = 14.dp, vertical = 6.dp)
    ) {
        Text(
            text = chipLabel,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = chipTextColor
        )
    }
}

@Composable
fun ClaimDetailCard(claim: Claim) {
    val (statusColor, statusBg, statusSymbol) = when (claim.status) {
        "VERIFIED" -> Triple(VerifiedGreen, VerifiedGreen.copy(alpha = 0.1f), "✓ Verified")
        "CONTRADICTED" -> Triple(MisinfoRed, MisinfoRed.copy(alpha = 0.1f), "✗ Refuted")
        else -> Triple(ClickbaitAmber, ClickbaitAmber.copy(alpha = 0.1f), "⚠ Unverified")
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(statusBg)
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = statusSymbol,
                            style = MaterialTheme.typography.labelSmall,
                            color = statusColor,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                // Highlighted claim statement
                Text(
                    text = claim.statement,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(6.dp))
                // Analytical forensic justification explanation
                Text(
                    text = claim.explanation,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

// --- SCREEN 3: HISTORY LOG SCREEN ---
@Composable
fun HistoryScreen(viewModel: VeritasViewModel) {
    val history by viewModel.scanHistoryList.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Scanned Archives",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Historical review logs of past audits",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (history.isNotEmpty()) {
                    TextButton(onClick = { viewModel.clearScansHistory() }) {
                        Text(
                            text = "Clear All",
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        if (history.isEmpty()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 80.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(text = "🗄️", fontSize = 48.sp)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Archive Log Cabinet is Empty",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Verifiably scanned article targets will appear here.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            items(history, key = { it.id }) { scan ->
                HistoryRowCard(scan, viewModel)
            }
        }
    }
}

@Composable
fun HistoryRowCard(scan: ScanEntity, viewModel: VeritasViewModel) {
    val focusManager = LocalFocusManager.current
    val chipBg = when (scan.trustLevel) {
        "VERIFIED" -> VerifiedGreen
        "CLICKBAIT" -> ClickbaitAmber
        else -> MisinfoRed
    }

    val dateStr = SimpleDateFormat("MMM dd, yyyy · HH:mm", Locale.getDefault()).format(Date(scan.timestamp))

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable {
                focusManager.clearFocus()
                viewModel.selectScanReport(scan)
            },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(chipBg, CircleShape)
                    )
                    Text(
                        text = scan.trustLevel,
                        style = MaterialTheme.typography.labelSmall,
                        color = chipBg,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "|  $dateStr",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = scan.title,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 1
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Score: ${scan.confidenceScore}%  ·  Perspective: ${scan.perspective}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            IconButton(onClick = {
                focusManager.clearFocus()
                viewModel.deleteHistoricalScan(scan.id)
            }) {
                Text(text = "🗑️", fontSize = 18.sp)
            }
        }
    }
}

// --- SCREEN 4: USER PROFILE SCREEN ---
@Composable
fun ProfileScreen(viewModel: VeritasViewModel) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        // User Profile Header
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Row(
                    modifier = Modifier.padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Profile picture fallback
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .border(3.dp, MaterialTheme.colorScheme.surfaceVariant, CircleShape)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "👨‍💼", fontSize = 36.sp)
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column {
                        Text(
                            text = "Alex Reed",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f))
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "PRO MEMBER",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.secondary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = "ID: 4829-VX",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // Subscription Plan Bento & Active Scans Capacity Meter Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Plan
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "PLAN PROFILE",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "Manage",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.secondary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Pro Annual",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Next: Oct 12, 2026",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Scans done
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "FORENSIC SCANS",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "${viewModel.forensicScansDoneCount}/100",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        LinearProgressIndicator(
                            progress = { viewModel.forensicScansDoneCount / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = MaterialTheme.colorScheme.secondary,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Resets in 14 days",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Settings Groups Section: Account Settings
        item {
            ProfileGroupCard(title = "ACCOUNT SETTINGS") {
                ProfileSettingRow(label = "👤 Edit Account Details")
                HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant, thickness = 1.dp)
                ProfileSettingRow(label = "✉️ Email Preferences")
            }
        }

        // Settings Groups Section: Security
        item {
            ProfileGroupCard(title = "SECURITY") {
                ProfileSettingRow(label = "🔒 Change Credentials")
                HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant, thickness = 1.dp)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 14.dp, horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "🛡️ Two-Factor Authentication",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(VerifiedGreen.copy(alpha = 0.15f))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "ACTIVE",
                            style = MaterialTheme.typography.labelSmall,
                            color = VerifiedGreen,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Settings Groups Section: App Preferences
        item {
            ProfileGroupCard(title = "APP PREFERENCES") {
                // Dark Mode preference toggler logic
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp, horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "🌙 Dark Mode Style",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Switch(
                        checked = viewModel.isDarkModeEnabled,
                        onCheckedChange = { viewModel.isDarkModeEnabled = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = MaterialTheme.colorScheme.secondary,
                            checkedTrackColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.5f)
                        )
                    )
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant, thickness = 1.dp)
                // Risk alerts
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp, horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "🔔 High-Risk Critical Alerts",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Push alerts for confirmed urgent misinformation.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = viewModel.isHighRiskAlertsEnabled,
                        onCheckedChange = { viewModel.isHighRiskAlertsEnabled = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = MaterialTheme.colorScheme.secondary,
                            checkedTrackColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.5f)
                        )
                    )
                }
            }
        }

        // Settings Groups Section: Legal & Information
        item {
            ProfileGroupCard(title = "SUPPORT & LEGAL") {
                ProfileSettingRow(label = "❓ Help Center")
                HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant, thickness = 1.dp)
                ProfileSettingRow(label = "📜 Terms of Service")
                HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant, thickness = 1.dp)
                ProfileSettingRow(label = "👁️ Privacy Policy")
            }
        }

        // Logout button matching the visual spec style exactly (Crimson-tinted Exit)
        item {
            val focusManager = LocalFocusManager.current
            Button(
                onClick = {
                    focusManager.clearFocus()
                    viewModel.activeTab = VeritasTab.SCANNER
                    viewModel.activeScanReport = null
                    viewModel.scannerInputText = ""
                    viewModel.errorMessage = null
                    viewModel.forensicScansDoneCount = 84
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error.copy(alpha = 0.12f),
                    contentColor = MaterialTheme.colorScheme.error
                )
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "🚪", fontSize = 18.sp)
                    Text(
                        text = "Logout from True Logic",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        item {
            Text(
                text = "Version 2.4.1 (Stable Build)",
                style = MaterialTheme.typography.bodySmall,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp, bottom = 12.dp)
            )
        }
    }
}

@Composable
fun ProfileGroupCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column {
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(start = 4.dp, bottom = 6.dp)
        )
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
            content = content
        )
    }
}

@Composable
fun ProfileSettingRow(label: String) {
    val focusManager = LocalFocusManager.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { focusManager.clearFocus() }
            .padding(vertical = 14.dp, horizontal = 16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.primary
        )
        Text(text = "›", fontSize = 22.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

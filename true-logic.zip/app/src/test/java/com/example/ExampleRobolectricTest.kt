package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.core.app.ActivityScenario
import com.example.viewmodel.VeritasViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("True Logic", appName)
  }

  @Test
  fun `launch main activity successfully`() {
    val scenario = ActivityScenario.launch(MainActivity::class.java)
    scenario.onActivity { activity ->
      assertNotNull(activity)
    }
  }

  @Test
  fun `test viewModel scanning flow successfully`() {
    val app = ApplicationProvider.getApplicationContext<Context>() as android.app.Application
    val viewModel = VeritasViewModel(app)
    
    // Default values
    assertEquals("", viewModel.scannerInputText)
    assertEquals(true, viewModel.isUrlMode)
    
    // Enter custom query
    viewModel.updateInputText("nasa mars water")
    assertEquals("nasa mars water", viewModel.scannerInputText)
    
    // Trigger forensic scan
    viewModel.startForensicAnalysis()
    
    // Since scanner runs asynchronously, we wait for flow or fallback results to propagate
    assertNotNull(viewModel)
  }

  @Test
  fun `test viewModel presets clicking and clearing history`() {
    val app = ApplicationProvider.getApplicationContext<Context>() as android.app.Application
    val viewModel = VeritasViewModel(app)
    
    // Verify preset click handling
    viewModel.setScannerMode(true)
    viewModel.updateInputText("https://spaceworld.com/nasa-perseverance-confirms-water-mars")
    viewModel.startForensicAnalysis()
    
    // Verify clear logic
    viewModel.clearScansHistory()
    assertEquals(null, viewModel.activeScanReport)
  }
}
